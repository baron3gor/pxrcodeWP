<?php 
//Silent is golden